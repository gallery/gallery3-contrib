<?php defined('SYSPATH') OR die('No direct access allowed.');

/**
 * Ident string added to each syslog message
 */
$config['ident'] = 'KohanaPHP';