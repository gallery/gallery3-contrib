<?php
/**
 * If using HTMLPurifier then this option allows setting an 
 * alternative path for the cache data. Note that that path 
 * must be an absolute location.
 */
$config['cache'] = '/tmp/htmlpurifier';
