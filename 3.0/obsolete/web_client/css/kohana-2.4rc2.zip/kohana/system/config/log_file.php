<?php defined('SYSPATH') OR die('No direct access allowed.');

/**
 * Message logging directory.
 */
$config['log_directory'] = APPPATH.'logs';

/**
 * Permissions of the log file
 */
$config['posix_permissions'] = 0644;