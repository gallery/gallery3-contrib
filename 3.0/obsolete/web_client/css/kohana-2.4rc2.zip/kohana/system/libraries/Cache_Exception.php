<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
 * $Id: Kohana_User_Exception.php 4543 2009-09-04 16:58:56Z nodren $
 *
 * @package    Core
 * @author     Kohana Team
 * @copyright  (c) 2007-2009 Kohana Team
 * @license    http://kohanaphp.com/license
 */

class Cache_Exception_Core extends Kohana_Exception {}
// End Kohana User Exception
